# YT Downloader - Extension Chrome

Ajoute un bouton **Télécharger** directement sur les pages vidéo YouTube.

---

## 📦 Installation

1. **Télécharge et décompresse** le dossier `yt-downloader-extension`

2. **Ouvre Chrome** et va sur :  
   `chrome://extensions/`

3. **Active le Mode développeur** (interrupteur en haut à droite)

4. Clique sur **"Charger l'extension non empaquetée"**

5. **Sélectionne le dossier** `yt-downloader-extension`

6. L'extension est installée ! Va sur YouTube et ouvre une vidéo 🎉

---

## 🎯 Utilisation

- Va sur n'importe quelle vidéo YouTube (`youtube.com/watch?v=...`)
- Un bouton rouge **"Télécharger"** apparaît dans la barre d'actions
- Clique dessus et choisis :
  - **1080p / 720p / 480p / 360p** → Vidéo MP4
  - **Audio seulement** → MP3
  - **Ouvrir dans Cobalt** → Service en ligne avancé

---

## ⚠️ Notes importantes

- Le téléchargement passe par **Y2mate** (service tiers gratuit)
- Pour les meilleures options, utilise **Cobalt.tools** (recommandé)
- Compatible avec **Chrome, Edge, Brave, et Opera**

---

## 🗂️ Structure des fichiers

```
yt-downloader-extension/
├── manifest.json    → Configuration de l'extension
├── content.js       → Script injecté dans YouTube
├── style.css        → Style du bouton
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```
