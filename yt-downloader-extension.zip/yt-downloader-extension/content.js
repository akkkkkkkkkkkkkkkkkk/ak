// YT Downloader - Content Script
// S'injecte automatiquement sur YouTube et ajoute un bouton de téléchargement

(function () {
  'use strict';

  const COBALT_API = 'https://cobalt.tools/';

  function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('v');
  }

  function getVideoTitle() {
    const titleEl =
      document.querySelector('h1.ytd-video-primary-info-renderer yt-formatted-string') ||
      document.querySelector('h1.style-scope.ytd-watch-metadata yt-formatted-string') ||
      document.querySelector('#title h1 yt-formatted-string') ||
      document.querySelector('h1.ytd-watch-metadata');
    return titleEl ? titleEl.textContent.trim() : 'video';
  }

  function createDownloadButton() {
    const btn = document.createElement('div');
    btn.id = 'ytdl-btn';
    btn.innerHTML = `
      <button id="ytdl-main-btn" title="Télécharger la vidéo">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2v13m0 0l-4-4m4 4l4-4M3 17v2a2 2 0 002 2h14a2 2 0 002-2v-2" 
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Télécharger</span>
      </button>
      <div id="ytdl-dropdown" class="ytdl-hidden">
        <div class="ytdl-title">Choisir le format</div>
        <a class="ytdl-option" data-format="mp4" data-quality="1080">
          <span class="ytdl-quality">1080p</span><span class="ytdl-ext">MP4</span>
        </a>
        <a class="ytdl-option" data-format="mp4" data-quality="720">
          <span class="ytdl-quality">720p</span><span class="ytdl-ext">MP4</span>
        </a>
        <a class="ytdl-option" data-format="mp4" data-quality="480">
          <span class="ytdl-quality">480p</span><span class="ytdl-ext">MP4</span>
        </a>
        <a class="ytdl-option" data-format="mp4" data-quality="360">
          <span class="ytdl-quality">360p</span><span class="ytdl-ext">MP4</span>
        </a>
        <div class="ytdl-separator"></div>
        <a class="ytdl-option" data-format="mp3">
          <span class="ytdl-quality">Audio seulement</span><span class="ytdl-ext">MP3</span>
        </a>
        <div class="ytdl-separator"></div>
        <a class="ytdl-option ytdl-cobalt" data-format="cobalt">
          <span class="ytdl-quality">🔗 Ouvrir dans Cobalt</span>
        </a>
      </div>
    `;
    return btn;
  }

  function openCobalt(videoId) {
    const url = `https://cobalt.tools/#${encodeURIComponent('https://www.youtube.com/watch?v=' + videoId)}`;
    window.open(url, '_blank');
  }

  function openY2mate(videoId, quality, format) {
    // Y2mate is a widely used, free YouTube downloader
    const ytUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const url = `https://www.y2mate.com/youtube/${videoId}`;
    window.open(url, '_blank');
  }

  function attachEvents(btn) {
    const mainBtn = btn.querySelector('#ytdl-main-btn');
    const dropdown = btn.querySelector('#ytdl-dropdown');

    mainBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('ytdl-hidden');
    });

    btn.querySelectorAll('.ytdl-option').forEach((opt) => {
      opt.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const format = opt.dataset.format;
        const quality = opt.dataset.quality;
        const videoId = getVideoId();

        if (!videoId) {
          alert("Impossible de trouver l'ID de la vidéo. Assurez-vous d'être sur une page vidéo YouTube.");
          return;
        }

        dropdown.classList.add('ytdl-hidden');

        if (format === 'cobalt') {
          openCobalt(videoId);
        } else {
          openY2mate(videoId, quality, format);
        }
      });
    });

    document.addEventListener('click', () => {
      dropdown.classList.add('ytdl-hidden');
    });
  }

  function injectButton() {
    // Ne pas dupliquer
    if (document.getElementById('ytdl-btn')) return;

    // Attendre que la barre d'actions YouTube soit chargée
    const actionsBar =
      document.querySelector('#actions-inner #menu') ||
      document.querySelector('#actions .ytd-watch-metadata') ||
      document.querySelector('ytd-watch-metadata #actions') ||
      document.querySelector('#below #actions');

    if (!actionsBar) return;

    const btn = createDownloadButton();
    attachEvents(btn);

    // Insérer le bouton dans la barre d'actions
    actionsBar.insertBefore(btn, actionsBar.firstChild);
  }

  // Observer les changements de page (YouTube est une SPA)
  let lastUrl = location.href;
  const observer = new MutationObserver(() => {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      setTimeout(injectButton, 1500);
    }
    if (location.pathname === '/watch' && !document.getElementById('ytdl-btn')) {
      injectButton();
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Injection initiale
  if (location.pathname === '/watch') {
    const tryInject = setInterval(() => {
      injectButton();
      if (document.getElementById('ytdl-btn')) clearInterval(tryInject);
    }, 800);
    setTimeout(() => clearInterval(tryInject), 10000);
  }
})();
